from __future__ import division

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.style.use(['seaborn-talk','paper'])
from cycler import cycler
matplotlib.rcParams['axes.prop_cycle'] = cycler(color=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'])

import os
import numpy
import copy
import pycbc
import pycbc.tmpltbank
import pycbc.psd
import pycbc.pnutils
from pycbc import pnutils
from pycbc.types import Array, FrequencySeries
from pycbc.filter import match
from pycbc.waveform import get_fd_waveform
import difflib
import sys
import matplotlib
import lal, lalsimulation
matplotlib.use('Agg')
import pylab

print lalsimulation.__file__

match_val = 0.97

def update_mass_parameters(tmpltbank_class):
    """
    Choose various sets of mass parameters for testing.
    """
    num_comp_masses = 3
    min_mass1 = [1,2,6]
    max_mass1 = [5,8,12]
    min_mass2 = [1,1,1]
    max_mass2 = [5,5,5]
    num_tot_masses = 3
    # These *must* be provided
    min_tot_mass = [None, 2.5, 3.5]
    max_tot_mass = [None, 11, 7.5]
    num_chirp_masses = 3
    max_chirp_mass = [None, 2.43, 3.5]
    min_chirp_mass = [None, 1.218, 2.43]
    num_etas = 3
    max_eta = [0.25, 0.24, 0.23]
    min_eta = [None, 0.16, 0.17]

    max_iter_idx = num_comp_masses * num_tot_masses *\
                   num_chirp_masses * num_etas

    for idx in xrange(max_iter_idx):
        comp_masses_idx = idx % num_comp_masses
        tmpltbank_class.min_mass1 = min_mass1[comp_masses_idx]
        tmpltbank_class.max_mass1 = max_mass1[comp_masses_idx]
        tmpltbank_class.min_mass2 = min_mass2[comp_masses_idx]
        tmpltbank_class.max_mass2 = max_mass2[comp_masses_idx]
        reduced_idx = idx // num_comp_masses
        tot_mass_idx = reduced_idx % num_tot_masses
        tmpltbank_class.min_total_mass = min_tot_mass[tot_mass_idx]
        tmpltbank_class.max_total_mass = max_tot_mass[tot_mass_idx]
        reduced_idx = reduced_idx // num_tot_masses
        chirp_mass_idx = reduced_idx % num_chirp_masses
        tmpltbank_class.min_chirp_mass = min_chirp_mass[chirp_mass_idx]
        tmpltbank_class.max_chirp_mass = max_chirp_mass[chirp_mass_idx]
        reduced_idx = reduced_idx // num_chirp_masses
        eta_idx = reduced_idx
        tmpltbank_class.max_eta = max_eta[eta_idx]
        tmpltbank_class.min_eta = min_eta[eta_idx]
        yield idx

    return


# Parameters
time_length = 32
deltaF = 1. / time_length
f_low = 15
f_upper = 2048
f0 = 70
sample_rate = 4096
pn_order = 'tidalTesting'
min_mass1 = 1.
min_mass2 = 1.
max_mass1 = 5.
max_mass2 = 5.
max_ns_spin_mag = 0.5
max_bh_spin_mag = 0.9
ns_bh_boundary_mass = 2.0
min_total_mass = 2.5
max_total_mass = 6.0
max_chirp_mass = 2.437
min_chirp_mass = 1.220
max_eta = 0.24
min_eta = 0.16
psd_size = int(time_length * sample_rate / 2.) + 1
desired_match = 0.97

if os.path.isfile('test/data/ZERO_DET_high_P.txt'):
    data_dir = 'test/data/'
elif os.path.isfile('data/ZERO_DET_high_P.txt'):
    data_dir = 'data/'
else:
    assertTrue(False, msg="Cannot find data files!")
psd = pycbc.psd.from_txt('%sZERO_DET_high_P.txt' %(data_dir),\
                psd_size, deltaF, f_low, is_asd_file=True)
#psd.resize(sample_rate*time_length / 2 + 1)
metricParams = pycbc.tmpltbank.metricParameters(pn_order,\
                         f_low, f_upper, deltaF, f0)
metricParams.psd = psd

massRangeParams = pycbc.tmpltbank.massRangeParameters(min_mass1,\
                            max_mass1, min_mass2, max_mass2,\
                            maxNSSpinMag=max_ns_spin_mag,\
                            maxBHSpinMag=max_bh_spin_mag,\
                            maxTotMass=max_total_mass,\
                            minTotMass=min_total_mass,\
                            ns_bh_boundary_mass=ns_bh_boundary_mass)
metricParams = pycbc.tmpltbank.determine_eigen_directions(metricParams)
vals=pycbc.tmpltbank.estimate_mass_range(100000, massRangeParams,\
               metricParams, f_upper, covary=False)
cov = numpy.cov(vals)
_, evecsCV = numpy.linalg.eig(cov)
metricParams.evecsCV = {}
metricParams.evecsCV[f_upper] = evecsCV

mass1a, mass2a, spin1za, spin2za = \
                 pycbc.tmpltbank.get_random_mass(10, massRangeParams)
mass1b, mass2b, spin1zb, spin2zb = \
                 pycbc.tmpltbank.get_random_mass(10, massRangeParams)

_snr = None
import math
import pycbc.types
import pycbc.filter

def vector_peak_interp(points):
    dy = 0.5 * (points[2] - points[0])
    d2y = 2. * points[1] - points[0] - points[2]
    return points[1] + 0.5 * dy * dy / d2y

def match_interp(vec1, vec2, psd=None, low_frequency_cutoff=None,
                 high_frequency_cutoff=None, v1_norm=None, v2_norm=None):
    htilde = pycbc.filter.make_frequency_series(vec1)
    stilde = pycbc.filter.make_frequency_series(vec2)
    
    #print len(htilde), len(stilde), len(psd)

    N = (len(htilde)-1) * 2

    #_snr = pycbc.types.zeros(N,dtype=htilde1.dtype)
    global _snr
    if _snr is None or _snr.dtype != htilde.dtype or len(_snr) != N:
        _snr = pycbc.types.zeros(N,dtype=pycbc.types.complex_same_precision_as(vec1))
    snr, _, snr_norm = pycbc.filter.matched_filter_core(htilde,stilde,psd,low_frequency_cutoff,
                             high_frequency_cutoff, v1_norm, out=_snr)
    maxsnr, max_id = snr.abs_max_loc()
    if v2_norm is None:
        v2_norm = pycbc.filter.sigmasq(stilde, psd, low_frequency_cutoff, high_frequency_cutoff)
    
    points_arr = abs(snr[numpy.arange(max_id-1,max_id+2) % N]) * snr_norm / math.sqrt(v2_norm)
    return vector_peak_interp(points_arr)

def shift_lal_phasing(lal_phasing, delta_lambda, lin_ord, log_ord, f0, total_mass):
    pim = lal.PI * (total_mass)*lal.MTSUN_SI
    pmf = pim * f0
    pmf13 = pmf**(1./3.)
    logpim13 = numpy.log((pim)**(1./3.))
    
    new_phasing = lalsimulation.PNPhasingSeries()
    new_phasing.v[:] = lal_phasing.v[:]
    new_phasing.vlogv[:] = lal_phasing.vlogv[:]
    new_phasing.vlogvsq[:] = lal_phasing.vlogvsq[:]
    
    if log_ord == 0:
        lal_diff = delta_lambda / (pmf13**(-5+lin_ord))
        new_phasing.v[lin_ord] = new_phasing.v[lin_ord] + lal_diff
    elif log_ord == 1:
        lal_l_diff = delta_lambda / (pmf13**(-5+lin_ord))
        new_phasing.vlogv[lin_ord] = new_phasing.vlogv[lin_ord] + lal_l_diff
        # Also need to change non log term
        pycbc_nl_diff = lal_l_diff * logpim13
        lal_nl_diff = - pycbc_nl_diff
        new_phasing.v[lin_ord] = new_phasing.v[lin_ord] + lal_nl_diff
    else:
        raise ValueError()
    return new_phasing


def compute_some_matches_pt_unmaximized(metricParams, desired_match):
    
    output_dict = {}
    
    num_metric_params_TI = copy.deepcopy(metricParams)

    metric_size = len(num_metric_params_TI.evals[f_upper])

    laldict = lal.CreateDict()
    # I need to create a waveform from a stock location. It shouldn't matter what this is, as we are going
    # to override the termination frequency anyway. The global parameter space stuff still seems to hold, so I
    # think only dlambda matters, not the original value of lambdas.
    mass1s, mass2s, spin1zs, spin2zs = \
         pycbc.tmpltbank.get_random_mass(1, massRangeParams)
    # And here's where we override what the frequencies will be. 
    freqs = numpy.arange(f_upper*int(1./metricParams.deltaF + 0.5)+1) * metricParams.deltaF
    fs = lal.CreateREAL8Vector(f_upper * int(1./metricParams.deltaF + 0.5) + 1)
    fs.data[:] = freqs[:]

    # Create our stock waveform. Note that we extract the phasing array so that we can directly change lambdas
    # and then generate a new waveform.
    mass1 = mass1s[0]
    mass2 = mass2s[0]
    spin1z = spin1zs[0]
    spin2z = spin2zs[0]
    phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
        (mass1, mass2, spin1z, spin2z, laldict)
    wform1 = lalsimulation.SimInspiralTaylorF2Core\
        (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
         lal.PC_SI*1000000, laldict, phasing)
    wform1 = FrequencySeries(wform1.data.data[:], delta_f=metricParams.deltaF,
                             epoch=wform1.epoch)
    
    def orders_generator():
        for log_term in [0,1]:
            for phase_order in range(13):
                yield (phase_order, log_term)
    
    for lin_ord, log_ord in orders_generator():
        # Use Fisher Matrix to guess what we should move lambda by for a diff of [desired_match]
        fisher_matrix = num_metric_params_TI.moments[(7 - (lin_ord - 5)*2,log_ord*2)][f_upper] * 0.5
        overlap = 0
        # We're then going to iterate to figure out what we need to do to get desired_match
        int_count = 0
        while abs((overlap - desired_match) / (1-desired_match)) > 0.00001:       
            diff = ((1 - desired_match) / fisher_matrix)**0.5
            # Explicitly shift the phasing array by this amount        
            new_phasing = shift_lal_phasing(phasing, diff, lin_ord, log_ord, num_metric_params_TI.f0, mass1 + mass2)
            wform2 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
                 lal.PC_SI*1000000, laldict, new_phasing)
            wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                     epoch=wform1.epoch)
            overlap = (pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                       low_frequency_cutoff=15)).real
            #print overlap, desired_match, diff, lin_ord, log_ord
            fisher_matrix = (1 - overlap) / diff**2
            int_count += 1
            if int_count > 60:
                print overlap, desired_match, diff, lin_ord, log_ord
                raise ValueError()
        diff = ((1 - desired_match) / fisher_matrix)**0.5

        curr_out = [1]
        for i in range(1, 41):
            curr_contribution = num_metric_params_TI.moments[(7 - (lin_ord - 5)*(2*i),log_ord*(2*i))][f_upper] * diff**(2*i)
            curr_out.append(curr_contribution / math.factorial(2*i) * (-1)**i)
        
        output_dict[(lin_ord, log_ord)] = [tuple(curr_out), diff]

    return output_dict

# START HERE START HERE

xvals = {}
yvals = {}

for match_val in [0.9, 0.95, 0.97, 0.98, 0.99, 0.995, 0.999, 0.9999, 0.99999]:

  match_contrib_dict = compute_some_matches_pt_unmaximized(metricParams, match_val)

  def get_match_vals(match_contrib_dict, corr_ord):
    outs = []
    for i in range(13):
        if (i,0) not in match_contrib_dict:
            continue
        match = 0
        for j in range(corr_ord + 1):
            match += match_contrib_dict[(i,0)][0][j]
        outs.append((i,match))
    return outs

  outs = get_match_vals(match_contrib_dict, 1)
  # Why there's no "unzip" function, I don't know!
  x,y = zip(*outs)
  xvals[(match_val, 1, 0)] = x
  yvals[(match_val, 1, 0)] = abs(numpy.array(y) - match_val) / (1-match_val)

  for i in range(2, 41):
    outs = get_match_vals(match_contrib_dict, i)
    # Why there's no "unzip" function, I don't know!
    x,y = zip(*outs)
    xvals[(match_val, i, 0)] = x
    yvals[(match_val, i, 0)] = abs(numpy.array(y) - match_val) / (1-match_val)


for i in range(1,41):
  pylab.figure()
  pylab.title("$(\Delta \lambda_{i,0})^{" + "{}".format(i*2) + "}$ terms")
  for match_val in [0.9, 0.95, 0.97, 0.98, 0.99, 0.995, 0.999, 0.9999, 0.99999]:
      x = xvals[(match_val, i, 0)]
      y = yvals[(match_val, i, 0)]
      pylab.semilogy([jjj/2. for jjj in x], y, label=match_val)
      pylab.ylabel("Fractional error in overlap")
      pylab.xlabel("PN order")
      pylab.tight_layout()
      pylab.ylim([1E-5,1000])
      pylab.xlim([-3,6.25])
      pylab.xticks([0,1,2,3,4,5,6])
      pylab.legend(loc='upper left')
  if i == 1:
      pylab.savefig('Figure3a.pdf')
  if i == 2:
      pylab.savefig('Figure4a.pdf')
  if i == 10:
      pylab.savefig('Figure4b.pdf')
  if i == 20:
      pylab.savefig('Figure4c.pdf')
  pylab.savefig('fisher_matrix_errors_{}.png'.format(i))


#assert(False)

pylab.figure()
pylab.title("$(\Delta \lambda_{i,1})^2$ terms")
for match_val in [0.9, 0.95, 0.97, 0.98, 0.99, 0.995, 0.999, 0.9999, 0.99999]:

  match_contrib_dict = compute_some_matches_pt_unmaximized(metricParams, match_val)

  def get_match_vals(match_contrib_dict, corr_ord):
    outs = []
    for i in range(13):
        if (i,0) not in match_contrib_dict:
            continue
        match = 0
        for j in range(corr_ord + 1):
            match += match_contrib_dict[(i,1)][0][j]
        outs.append((i,match))
    return outs

  outs = get_match_vals(match_contrib_dict, 1)
  # Why there's no "unzip" function, I don't know!
  x,y = zip(*outs)
  pylab.semilogy([jjj/2. for jjj in x], abs(numpy.array(y) - match_val) / (1-match_val), label=match_val)
pylab.ylabel("Fractional error in overlap")
pylab.xlabel("PN order")
pylab.tight_layout()
pylab.ylim([1E-5,1000])
pylab.xlim([-3,6.25])
pylab.xticks([0,1,2,3,4,5,6])
pylab.legend(loc='upper left')
pylab.savefig('Figure3b.pdf')


