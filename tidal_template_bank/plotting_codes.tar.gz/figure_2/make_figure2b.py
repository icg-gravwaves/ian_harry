import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.style.use(['seaborn-talk','paper'])

from support import *

met_tensor = MetrixTensor(metricParams.moments, metricParams.fUpper)

desired_match = 0.95
output_2d_example_095 = create_2d_variations_physical_mass(met_tensor, desired_match, relative_scale=1.0)

desired_match = 0.96
output_2d_example_096 = create_2d_variations_physical_mass(met_tensor, desired_match, relative_scale=1.0)

desired_match = 0.97
output_2d_example_097 = create_2d_variations_physical_mass(met_tensor, desired_match, relative_scale=1.0)

desired_match = 0.98
output_2d_example_098 = create_2d_variations_physical_mass(met_tensor, desired_match, relative_scale=1.0)

desired_match = 0.99
output_2d_example_099 = create_2d_variations_physical_mass(met_tensor, desired_match, relative_scale=1.0)

desired_match = 0.995
output_2d_example_0995 = create_2d_variations_physical_mass(met_tensor, desired_match, relative_scale=1.0)

desired_match = 0.999
output_2d_example_0999 = create_2d_variations_physical_mass(met_tensor, desired_match, relative_scale=1.0)

mchirp=1.06185875879
eta=0.24
pylab.figure()
count = 0
for o2de in [output_2d_example_097]:
    proper_points_x = []
    proper_points_y = []
    calculated_points_x = {}
    calculated_points_y = {}
    angle = []
    matches = {}
    for i in range(1, 11):
        calculated_points_x[i] = []
        calculated_points_y[i] = []
        matches[i] = []

    sorted_keys = sorted(o2de.keys())
    for key in sorted_keys:
        diff1 = o2de[key][2]
        diff2 = o2de[key][3]
        proper_points_x.append(diff1)
        proper_points_y.append(diff2)
        angle.append(key)
        curr_diff = 1
        for i in [1]:
            curr_diff = o2de[key][1][i-1]
            calculated_points_x[i].append(curr_diff[0])
            calculated_points_y[i].append(curr_diff[1])

    pylab.plot(mchirp-(numpy.array(calculated_points_x[1])),
               eta-(numpy.array(calculated_points_y[1])), 'r--')

    pylab.plot(mchirp-(numpy.array(proper_points_x)),
               eta-(numpy.array(proper_points_y)), 'b-')


pylab.xlabel('$\Delta \mathcal{M}$')
pylab.ylabel('$\Delta \eta$')
pylab.xlim([-0.00006, 0.00006])
pylab.xticks([-0.00006, -0.00003, 0, 0.00003, 0.00006])
pylab.tight_layout()
pylab.savefig('Figure2b.pdf')

pylab.figure()
odes = [output_2d_example_095, output_2d_example_096, output_2d_example_097,
        output_2d_example_098, output_2d_example_099, output_2d_example_0995,
        output_2d_example_0999]
overlaps = [0.95, 0.96, 0.97, 0.98, 0.99, 0.995, 0.999]


for jjj in range(7):
    o2de = odes[jjj]
    olap = overlaps[jjj]
    pylab.figure()
    proper_points_x = []
    proper_points_y = []
    calculated_points_x = {}
    calculated_points_y = {}
    angle = []
    matches = {}
    for i in range(1, 11):
        calculated_points_x[i] = []
        calculated_points_y[i] = []
        matches[i] = []

    sorted_keys = sorted(o2de.keys())
    for key in sorted_keys:
        diff1 = o2de[key][2]
        diff2 = o2de[key][3]
        proper_points_x.append(diff1)
        proper_points_y.append(diff2)
        angle.append(key)
        curr_diff = 1
        for i in [1]:
            curr_diff = o2de[key][1][i-1]
            calculated_points_x[i].append(curr_diff[0])
            calculated_points_y[i].append(curr_diff[1])

    pylab.plot(mchirp-(numpy.array(calculated_points_x[1])),
               eta-(numpy.array(calculated_points_y[1])), 'r--')

    pylab.plot(mchirp-(numpy.array(proper_points_x)),
               eta-(numpy.array(proper_points_y)), 'b-')
    pylab.legend(['Fisher matrix', 'Numerical overlap'])
    pylab.title("Overlap of %s" % olap)
    pylab.xlabel('$\Delta \mathcal{M}$')
    pylab.ylabel('$\Delta \eta$')
    pylab.tight_layout()
    pylab.savefig('Figure2_video_%d.png' % (jjj+21))
    pylab.xlim([-0.00008,0.00008])
    pylab.ylim([-0.00085,0.00085])
    pylab.savefig('Figure2_video_%d.png' % (jjj+14))

