import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.style.use(['seaborn-talk','paper'])

from support import *

met_tensor = MetrixTensor(metricParams.moments, metricParams.fUpper)

desired_match = 0.95
output_2d_example_095 = create_2d_variations(met_tensor, [0,0], [2,0], desired_match, relative_scale=1., nvals=2000)

desired_match = 0.96
output_2d_example_096 = create_2d_variations(met_tensor, [0,0], [2,0], desired_match, relative_scale=0.2, nvals=2000)

desired_match = 0.97
output_2d_example_097 = create_2d_variations(met_tensor, [0,0], [2,0], desired_match, relative_scale=1., nvals=2000)

desired_match = 0.98
output_2d_example_098 = create_2d_variations(met_tensor, [0,0], [2,0], desired_match, relative_scale=0.2, nvals=2000)

desired_match = 0.99
output_2d_example_099 = create_2d_variations(met_tensor, [0,0], [2,0], desired_match, relative_scale=1., nvals=2000)

desired_match = 0.995
output_2d_example_0995 = create_2d_variations(met_tensor, [0,0], [2,0], desired_match, relative_scale=0.2, nvals=2000)

desired_match = 0.999
output_2d_example_0999 = create_2d_variations(met_tensor, [0,0], [2,0], desired_match, relative_scale=1., nvals=2000)

#desired_match = 0.9999
#output_2d_example_09999 = create_2d_variations(met_tensor, [0,0], [2,0], desired_match, relative_scale=1., nvals=500)

#desired_match = 0.99999
#output_2d_example_099999 = create_2d_variations(met_tensor, [0,0], [2,0], desired_match, relative_scale=1., nvals=500)

# Make plot of output_2d_example

pylab.figure()
for o2de in [output_2d_example_097]:
    proper_points_x = []
    proper_points_y = []
    calculated_points_x = {}
    calculated_points_y = {}
    matches = {}
    for i in range(1, 11):
        calculated_points_x[i] = []
        calculated_points_y[i] = []
        matches[i] = []

    sorted_keys = sorted(o2de.keys())
    for key in sorted_keys:
        diff1 = o2de[key][2]
        diff2 = o2de[key][3]
        proper_points_x.append(diff1)
        proper_points_y.append(diff2)
        curr_diff = 1
        for i in [1]:
            curr_diff = o2de[key][1][i-1]
            calculated_points_x[i].append(curr_diff[0])
            calculated_points_y[i].append(curr_diff[1])

    pylab.plot((numpy.array(calculated_points_x[1])), (numpy.array(calculated_points_y[1])), 'r--')
    #pylab.plot((numpy.array(calculated_points_x[11])), (numpy.array(calculated_points_y[11])), 'g-')
    pylab.plot((numpy.array(proper_points_x)), 
               (numpy.array(proper_points_y)), 'b-')

pylab.xlabel('$\Delta \lambda_{0,0}$')
pylab.ylabel('$\Delta \lambda_{2,0}$')
pylab.savefig('Figure2a.pdf')

odes = [output_2d_example_095, output_2d_example_096, output_2d_example_097,
        output_2d_example_098, output_2d_example_099, output_2d_example_0995,
        output_2d_example_0999]
overlaps = [0.95, 0.96, 0.97, 0.98, 0.99, 0.995, 0.999]

for jjj in range(7):
    o2de = odes[jjj]
    olap = overlaps[jjj]
    pylab.figure()

    proper_points_x = []
    proper_points_y = []
    calculated_points_x = {}
    calculated_points_y = {}
    matches = {}
    for i in range(1, 11):
        calculated_points_x[i] = []
        calculated_points_y[i] = []
        matches[i] = []

    sorted_keys = sorted(o2de.keys())
    for key in sorted_keys:
        diff1 = o2de[key][2]
        diff2 = o2de[key][3]
        proper_points_x.append(diff1)
        proper_points_y.append(diff2)
        curr_diff = 1
        for i in [1]:
            curr_diff = o2de[key][1][i-1]
            calculated_points_x[i].append(curr_diff[0])
            calculated_points_y[i].append(curr_diff[1])

    pylab.plot((numpy.array(calculated_points_x[1])), (numpy.array(calculated_points_y[1])), 'r--')
    #pylab.plot((numpy.array(calculated_points_x[11])), (numpy.array(calculated_points_y[11])), 'g-')
    pylab.plot((numpy.array(proper_points_x)),
               (numpy.array(proper_points_y)), 'b-')

    pylab.legend(['Fisher matrix', 'Numerical overlap'])
    pylab.title("Overlap of %s" % olap)
    pylab.xlabel('$\Delta \lambda_{0,0}$')
    pylab.ylabel('$\Delta \lambda_{2,0}$')
    pylab.savefig('Figure2_video_%d.png' % (jjj+7))
    pylab.xlim([-0.42,0.42])
    pylab.ylim([-0.77,0.77])
    pylab.savefig('Figure2_video_%d.png' % jjj)

