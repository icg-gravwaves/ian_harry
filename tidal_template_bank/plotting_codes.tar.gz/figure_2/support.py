from __future__ import division
import os
import numpy
import copy
import pycbc
import pycbc.tmpltbank
import pycbc.psd
import pycbc.pnutils
from pycbc import pnutils
from pycbc.types import Array, FrequencySeries
from pycbc.filter import match
from pycbc.waveform import get_fd_waveform
import difflib
import sys
import matplotlib
matplotlib.use('Agg')
import pylab
import lal, lalsimulation

# Parameters
time_length = 32
deltaF = 1. / time_length
f_low = 15
f_upper = 2048
f0 = 70
sample_rate = 4096
pn_order = 'tidalTesting'
min_mass1 = 1.
min_mass2 = 1.
max_mass1 = 5.
max_mass2 = 5.
max_ns_spin_mag = 0.5
max_bh_spin_mag = 0.9
ns_bh_boundary_mass = 2.0
min_total_mass = 2.5
max_total_mass = 6.0
max_chirp_mass = 2.437
min_chirp_mass = 1.220
max_eta = 0.24
min_eta = 0.16
psd_size = int(time_length * sample_rate / 2.) + 1
desired_match = 0.97


def update_mass_parameters(tmpltbank_class):
    """
    Choose various sets of mass parameters for testing.
    """
    num_comp_masses = 3
    min_mass1 = [1,2,6]
    max_mass1 = [5,8,12]
    min_mass2 = [1,1,1]
    max_mass2 = [5,5,5]
    num_tot_masses = 3
    # These *must* be provided
    min_tot_mass = [None, 2.5, 3.5]
    max_tot_mass = [None, 11, 7.5]
    num_chirp_masses = 3
    max_chirp_mass = [None, 2.43, 3.5]
    min_chirp_mass = [None, 1.218, 2.43]
    num_etas = 3
    max_eta = [0.25, 0.24, 0.23]
    min_eta = [None, 0.16, 0.17]

    max_iter_idx = num_comp_masses * num_tot_masses *\
                   num_chirp_masses * num_etas

    for idx in xrange(max_iter_idx):
        comp_masses_idx = idx % num_comp_masses
        tmpltbank_class.min_mass1 = min_mass1[comp_masses_idx]
        tmpltbank_class.max_mass1 = max_mass1[comp_masses_idx]
        tmpltbank_class.min_mass2 = min_mass2[comp_masses_idx]
        tmpltbank_class.max_mass2 = max_mass2[comp_masses_idx]
        reduced_idx = idx // num_comp_masses
        tot_mass_idx = reduced_idx % num_tot_masses
        tmpltbank_class.min_total_mass = min_tot_mass[tot_mass_idx]
        tmpltbank_class.max_total_mass = max_tot_mass[tot_mass_idx]
        reduced_idx = reduced_idx // num_tot_masses
        chirp_mass_idx = reduced_idx % num_chirp_masses
        tmpltbank_class.min_chirp_mass = min_chirp_mass[chirp_mass_idx]
        tmpltbank_class.max_chirp_mass = max_chirp_mass[chirp_mass_idx]
        reduced_idx = reduced_idx // num_chirp_masses
        eta_idx = reduced_idx
        tmpltbank_class.max_eta = max_eta[eta_idx]
        tmpltbank_class.min_eta = min_eta[eta_idx]
        yield idx

    return

if os.path.isfile('test/data/ZERO_DET_high_P.txt'):
    data_dir = 'test/data/'
elif os.path.isfile('./ZERO_DET_high_P.txt'):
    data_dir = './'
else:
    self.assertTrue(False, msg="Cannot find data files!")
psd = pycbc.psd.from_txt('%sZERO_DET_high_P.txt' %(data_dir),\
                psd_size, deltaF, f_low, is_asd_file=True)
#psd.resize(sample_rate*time_length / 2 + 1)
metricParams = pycbc.tmpltbank.metricParameters(pn_order,\
                         f_low, f_upper, deltaF, f0)
metricParams.psd = psd

massRangeParams = pycbc.tmpltbank.massRangeParameters(min_mass1,\
                            max_mass1, min_mass2, max_mass2,\
                            maxNSSpinMag=max_ns_spin_mag,\
                            maxBHSpinMag=max_bh_spin_mag,\
                            maxTotMass=max_total_mass,\
                            minTotMass=min_total_mass,\
                            ns_bh_boundary_mass=ns_bh_boundary_mass)
metricParams = pycbc.tmpltbank.determine_eigen_directions(metricParams)
vals=pycbc.tmpltbank.estimate_mass_range(100000, massRangeParams,\
               metricParams, f_upper, covary=False)
cov = numpy.cov(vals)
_, evecsCV = numpy.linalg.eig(cov)
metricParams.evecsCV = {}
metricParams.evecsCV[f_upper] = evecsCV

mass1a, mass2a, spin1za, spin2za = \
                 pycbc.tmpltbank.get_random_mass(10, massRangeParams)
mass1b, mass2b, spin1zb, spin2zb = \
                 pycbc.tmpltbank.get_random_mass(10, massRangeParams)

_snr = None
import math
import pycbc.types
import pycbc.filter

def vector_peak_interp(points):
    dy = 0.5 * (points[2] - points[0])
    d2y = 2. * points[1] - points[0] - points[2]
    return points[1] + 0.5 * dy * dy / d2y

def match_interp(vec1, vec2, psd=None, low_frequency_cutoff=None,
                 high_frequency_cutoff=None, v1_norm=None, v2_norm=None):
    htilde = pycbc.filter.make_frequency_series(vec1)
    stilde = pycbc.filter.make_frequency_series(vec2)
    
    #print len(htilde), len(stilde), len(psd)

    N = (len(htilde)-1) * 2

    #_snr = pycbc.types.zeros(N,dtype=htilde1.dtype)
    global _snr
    if _snr is None or _snr.dtype != htilde.dtype or len(_snr) != N:
        _snr = pycbc.types.zeros(N,dtype=pycbc.types.complex_same_precision_as(vec1))
    snr, _, snr_norm = pycbc.filter.matched_filter_core(htilde,stilde,psd,low_frequency_cutoff,
                             high_frequency_cutoff, v1_norm, out=_snr)
    maxsnr, max_id = snr.abs_max_loc()
    if v2_norm is None:
        v2_norm = pycbc.filter.sigmasq(stilde, psd, low_frequency_cutoff, high_frequency_cutoff)
    
    points_arr = abs(snr[numpy.arange(max_id-1,max_id+2) % N]) * snr_norm / math.sqrt(v2_norm)
    return vector_peak_interp(points_arr)


def compute_numerical_metric(metricParams, desired_match, N_iterations=20):
    num_metric_params = copy.deepcopy(metricParams)

    laldict = lal.CreateDict()
    mass1s, mass2s, spin1zs, spin2zs = \
         pycbc.tmpltbank.get_random_mass(N_iterations,
                                         massRangeParams)
    freqs = numpy.arange(f_upper*int(1./metricParams.deltaF + 0.5)+1) * metricParams.deltaF
    fs = lal.CreateREAL8Vector(f_upper * int(1./metricParams.deltaF + 0.5) + 1)
    fs.data[:] = freqs[:]

    for i in range(len(mass1s)):
            mass1 = mass1s[i]
            mass2 = mass2s[i]
            spin1z = spin1zs[i]
            spin2z = spin2zs[i]
            phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
                (mass1, mass2, spin1z, spin2z, laldict)
            wform1 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 80., 0.,
                 lal.PC_SI*1000000, laldict, phasing)
            wform1 = FrequencySeries(wform1.data.data[:], delta_f=metricParams.deltaF,
                                     epoch=wform1.epoch)
            metric_size = len(metricParams.evals[f_upper])

            # Diagonal terms
            for metric_idx in range(metric_size):
                # Try and figure out how much I need to adjust that metric component by to get a specific match
                diff = ((1 - desired_match) / num_metric_params.metric[f_upper]\
                        [metric_idx,metric_idx])**0.5
                # Update the TF2 phasing structure to shift the corresponding phase by the correct amount
                new_phasing = pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                    (phasing, diff, metric_idx, mass1 + mass2,
                     num_metric_params)
                # Generate a new waveform with the updating phasing array. This is now unphysical, but TF2 is fine
                # with that.
                wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 80., 0.,
                     lal.PC_SI*1000000, laldict, new_phasing)
                # And cast to PyCBC format and compute match with the original waveform.
                wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                         epoch=wform1.epoch)
                overlap = match_interp(wform1, wform2, psd=psd,
                                    low_frequency_cutoff=15)
                # We update the metric to represent the updated prediction
                num_metric_params.metric[f_upper][metric_idx,metric_idx] \
                    = (1 - overlap) / (diff*diff)
                if (1 - overlap) / (diff*diff) < 0:
                    print overlap, diff, 1- overlap
                    raise ValueError()
                #print metric_idx, metric_idx, overlap, mass1, mass2

            #print
            
            # Cross terms
            for metric_idx1 in range(metric_size):
                for metric_idx2 in range(metric_size):
                    if metric_idx2 >= metric_idx1:
                        continue
                    # Cross terms follow the same process as before, but we need to deal with additional terms in
                    # the computation.
                    # Cross terms are computed using the already updated metric. Do we want this?
                    curr_metric_1 = num_metric_params.metric[f_upper]\
                        [metric_idx1, metric_idx1]
                    curr_metric_2 = num_metric_params.metric[f_upper]\
                        [metric_idx2, metric_idx2]
                    curr_metric_C = num_metric_params.metric[f_upper]\
                        [metric_idx1, metric_idx2]
                    if curr_metric_1 < 0 or curr_metric_2 < 0:
                        # This shouldn't happen. Hopefully next iteration it is fixed??
                        continue
                    diff_ratio = (curr_metric_1 / curr_metric_2)**0.5
                    diff1 = 1 - desired_match
                    diff1 /= curr_metric_1 + 2*diff_ratio*curr_metric_C + \
                        diff_ratio*diff_ratio*curr_metric_2
                    # FIXME
                    # This takes out the cross term. Not sure why!
                    # I guess this happens if the cross term makes the difference positive, which shouldn't
                    # be possible!
                    if diff1 < 0:
                        diff1 = 1 - desired_match
                        diff1 /= curr_metric_1 + \
                            diff_ratio*diff_ratio*curr_metric_2
                    diff1 = diff1**0.5
                    diff2 = diff1 * diff_ratio
                    if numpy.isnan(diff1) or numpy.isnan(curr_metric_1):
                        print "ERROR"
                        print curr_metric_1, curr_metric_2, curr_metric_C, diff1, diff2
                        print "ERROR"
                        raise ValueError()
                    # Then again we change the phasing by these amounts and test.
                    new_phasing = \
                        pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                        (phasing, diff1, metric_idx1, mass1 + mass2,
                         num_metric_params)
                    new_phasing = \
                        pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                        (new_phasing, diff2, metric_idx2, mass1 + mass2,
                         num_metric_params, edit_in_place=True)
                    wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 80., 0.,
                     lal.PC_SI*1000000, laldict, new_phasing)
                    wform2 = FrequencySeries\
                        (wform2.data.data[:], delta_f=metricParams.deltaF,
                         epoch=wform1.epoch)
                    overlap = match_interp(wform1, wform2, psd=psd,
                                       low_frequency_cutoff=15)
                    # The free component is the cross term, so that's what needs to change to make this work.
                    new_metric_comp = - curr_metric_1 / diff_ratio - \
                        diff_ratio * curr_metric_2 + \
                        (1 - overlap) / (diff1 * diff2)
                    new_metric_comp *= 0.5
                    num_metric_params.metric[f_upper]\
                        [metric_idx1,metric_idx2] = new_metric_comp
                    num_metric_params.metric[f_upper]\
                        [metric_idx2,metric_idx1] = new_metric_comp
                    #print metric_idx1, metric_idx2, overlap, mass1, mass2
                    #print curr_metric_1*diff1*diff1, curr_metric_2*diff2*diff2, curr_metric_C*diff1*diff2, curr_metric_1*diff1*diff1 + curr_metric_2*diff2*diff2 + 2*curr_metric_C*diff1*diff2
                    #print
    return num_metric_params


def compute_numerical_metric_unmaximized(metricParams, desired_match, N_iterations=20):

    num_metric_params_TI = copy.deepcopy(metricParams)

    metric_size = len(num_metric_params_TI.evals[f_upper])

    laldict = lal.CreateDict()
    mass1s, mass2s, spin1zs, spin2zs = \
         pycbc.tmpltbank.get_random_mass(N_iterations,
                                         massRangeParams)
    freqs = numpy.arange(f_upper*int(1./metricParams.deltaF + 0.5)+1) * metricParams.deltaF
    fs = lal.CreateREAL8Vector(f_upper * int(1./metricParams.deltaF + 0.5) + 1)
    fs.data[:] = freqs[:]

    num_metric_params_TI.time_unprojected_metric[f_upper][-1,-1] = \
        num_metric_params_TI.time_unprojected_metric[f_upper][-1,-1] * num_metric_params_TI.f0 * num_metric_params_TI.f0
    for metric_idx in range(metric_size):
        num_metric_params_TI.time_unprojected_metric[f_upper][-1,metric_idx] = \
            num_metric_params_TI.time_unprojected_metric[f_upper][-1,metric_idx] * (num_metric_params_TI.f0)
        num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx,-1] = \
            num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx,-1] * (num_metric_params_TI.f0)

    # It seems I'm dividing everything by 0.5 ... Why?
    for metric_idx1 in range(metric_size+1):
        for metric_idx2 in range(metric_size+1):
            num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx1, metric_idx2] = \
                num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx1, metric_idx2] * 0.5

    for i in range(len(mass1s)):
            mass1 = mass1s[i]
            mass2 = mass2s[i]
            spin1z = spin1zs[i]
            spin2z = spin2zs[i]
            phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
                (mass1, mass2, spin1z, spin2z, laldict)
            wform1 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 80., 0.,
                 lal.PC_SI*1000000, laldict, phasing)
            wform1 = FrequencySeries(wform1.data.data[:], delta_f=metricParams.deltaF,
                                     epoch=wform1.epoch)
            metric_size = len(num_metric_params_TI.evals[f_upper])

            # Time term
            diff = ((1 - desired_match) / num_metric_params_TI.time_unprojected_metric[f_upper][-1,-1])**0.5
            #print diff
            wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 80., diff,
                     lal.PC_SI*1000000, laldict, phasing)
            wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                         epoch=wform1.epoch)
            overlap = pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                   low_frequency_cutoff=15)
            overlap = abs(overlap)
            num_metric_params_TI.time_unprojected_metric[f_upper][-1,-1] \
                    = (1 - overlap) / (diff*diff)
            if (1 - overlap) / (diff*diff) < 0:
                print overlap, diff, 1- overlap
                raise ValueError()
            #print -1, -1, overlap
            #print "T", "T", overlap#, mass1, mass2     
            #raise ValueError()
            
            # Diagonal terms
            for metric_idx in range(metric_size):
                diff = ((1 - desired_match) / num_metric_params_TI.time_unprojected_metric[f_upper]\
                        [metric_idx,metric_idx])**0.5
                new_phasing = pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                    (phasing, diff, metric_idx, mass1 + mass2,
                     num_metric_params_TI)
                wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 80., 0.,
                     lal.PC_SI*1000000, laldict, new_phasing)
                wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                         epoch=wform1.epoch)
                overlap = abs(pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                    low_frequency_cutoff=15))
                num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx,metric_idx] \
                    = (1 - overlap) / (diff*diff)
                if (1 - overlap) / (diff*diff) < 0:
                    print overlap, diff, 1- overlap
                    raise ValueError()
                #print metric_idx, metric_idx, overlap
                #print metric_idx, metric_idx, overlap#, mass1, mass2
                #print num_metric_params.time_unprojected_metric[f_upper][metric_idx,metric_idx], num_metric_params.metric[f_upper][metric_idx,metric_idx]

            #print
            
            # Cross time terms
            for metric_idx1 in range(metric_size):
                curr_metric_1 = num_metric_params_TI.time_unprojected_metric[f_upper]\
                    [metric_idx1, metric_idx1]
                curr_metric_2 = num_metric_params_TI.time_unprojected_metric[f_upper]\
                    [-1, -1]
                curr_metric_C = num_metric_params_TI.time_unprojected_metric[f_upper]\
                    [metric_idx1, -1]
                diff_ratio = (curr_metric_1 / curr_metric_2)**0.5
                diff1 = 1 - desired_match
                diff1 /= curr_metric_1 + 2*diff_ratio*curr_metric_C + \
                    diff_ratio*diff_ratio*curr_metric_2
                if diff1 < 0:
                    diff1 = 1 - desired_match
                    diff1 /= curr_metric_1 + \
                        diff_ratio*diff_ratio*curr_metric_2
                diff1 = diff1**0.5
                diff2 = diff1 * diff_ratio

                if numpy.isnan(diff1) or numpy.isnan(curr_metric_1):
                        print "ERROR"
                        print curr_metric_1, curr_metric_2, curr_metric_C, diff1, diff2
                        print "ERROR"
                        raise ValueError()
                new_phasing = \
                        pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                        (phasing, diff1, metric_idx1, mass1 + mass2,
                         num_metric_params_TI)
                wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 80., diff2,
                     lal.PC_SI*1000000, laldict, new_phasing)
                wform2 = FrequencySeries\
                        (wform2.data.data[:], delta_f=metricParams.deltaF,
                         epoch=wform1.epoch)
                overlap = abs(pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                       low_frequency_cutoff=15))
                new_metric_comp = - curr_metric_1 / diff_ratio - \
                        curr_metric_2 * diff_ratio + \
                        (1 - overlap) / (diff1 * diff2)
                new_metric_comp *= 0.5
                num_metric_params_TI.time_unprojected_metric[f_upper]\
                        [metric_idx1,-1] = new_metric_comp
                num_metric_params_TI.time_unprojected_metric[f_upper]\
                        [-1,metric_idx1] = new_metric_comp
                #print -1, metric_idx1, overlap
                #print metric_idx1, "T", overlap#, mass1, mass2
                #print curr_metric_1*diff1*diff1, curr_metric_2*diff2*diff2, curr_metric_C*diff1*diff2, curr_metric_1*diff1*diff1 + curr_metric_2*diff2*diff2 + 2*curr_metric_C*diff1*diff2
                #print

            # Cross terms
            for metric_idx1 in range(metric_size):
                for metric_idx2 in range(metric_size):
                    if metric_idx2 >= metric_idx1:
                        continue
                    curr_metric_1 = num_metric_params_TI.time_unprojected_metric[f_upper]\
                        [metric_idx1, metric_idx1]
                    curr_metric_2 = num_metric_params_TI.time_unprojected_metric[f_upper]\
                        [metric_idx2, metric_idx2]
                    curr_metric_C = num_metric_params_TI.time_unprojected_metric[f_upper]\
                        [metric_idx1, metric_idx2]
                    if curr_metric_1 < 0 or curr_metric_2 < 0:
                        # This shouldn't happen. Hopefully next iteration it is fixed??
                        continue
                    diff_ratio = (curr_metric_1 / curr_metric_2)**0.5
                    diff1 = 1 - desired_match
                    diff1 /= curr_metric_1 + 2*diff_ratio*curr_metric_C + \
                        diff_ratio*diff_ratio*curr_metric_2
                    if diff1 < 0:
                        diff1 = 1 - desired_match
                        diff1 /= curr_metric_1 + \
                            diff_ratio*diff_ratio*curr_metric_2
                    diff1 = diff1**0.5
                    diff2 = diff1 * diff_ratio
                    if numpy.isnan(diff1) or numpy.isnan(curr_metric_1):
                        print "ERROR"
                        print curr_metric_1, curr_metric_2, curr_metric_C, diff1, diff2
                        print "ERROR"
                        raise ValueError()
                    new_phasing = \
                        pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                        (phasing, diff1, metric_idx1, mass1 + mass2,
                         num_metric_params_TI)
                    new_phasing = \
                        pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                        (new_phasing, diff2, metric_idx2, mass1 + mass2,
                         num_metric_params_TI, edit_in_place=True)
                    wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 80., 0.,
                     lal.PC_SI*1000000, laldict, new_phasing)
                    wform2 = FrequencySeries\
                        (wform2.data.data[:], delta_f=metricParams.deltaF,
                         epoch=wform1.epoch)
                    overlap = abs(pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                       low_frequency_cutoff=15))
                    new_metric_comp = - curr_metric_1 / diff_ratio - \
                        diff_ratio * curr_metric_2 + \
                        (1 - overlap) / (diff1 * diff2)
                    new_metric_comp *= 0.5
                    num_metric_params_TI.time_unprojected_metric[f_upper]\
                        [metric_idx1,metric_idx2] = new_metric_comp
                    num_metric_params_TI.time_unprojected_metric[f_upper]\
                        [metric_idx2,metric_idx1] = new_metric_comp
                    #print metric_idx1, metric_idx2, overlap
                    #print metric_idx1, metric_idx2, overlap
                    #print curr_metric_1*diff1*diff1, curr_metric_2*diff2*diff2, curr_metric_C*diff1*diff2, curr_metric_1*diff1*diff1 + curr_metric_2*diff2*diff2 + 2*curr_metric_C*diff1*diff2
                    #print


    for metric_idx1 in range(metric_size):
        for metric_idx2 in range(metric_size):
            mc1 = num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx1, metric_idx2]
            mc2 = num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx1, -1] / num_metric_params_TI.f0
            mc3 = num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx2, -1] / num_metric_params_TI.f0
            mc4 = num_metric_params_TI.time_unprojected_metric[f_upper][-1, -1] / (num_metric_params_TI.f0 * num_metric_params_TI.f0)
            num_metric_params_TI.metric[f_upper][metric_idx1, metric_idx2] = mc1 - mc2*mc3 / mc4
            
    return num_metric_params_TI


def compute_numerical_metric_pt_unmaximized(metricParams, desired_match, N_iterations=20):

    num_metric_params_TI = copy.deepcopy(metricParams)

    metric_size = len(num_metric_params_TI.evals[f_upper])

    laldict = lal.CreateDict()
    mass1s, mass2s, spin1zs, spin2zs = \
         pycbc.tmpltbank.get_random_mass(N_iterations,
                                         massRangeParams)
    freqs = numpy.arange(f_upper*int(1./metricParams.deltaF + 0.5)+1) * metricParams.deltaF
    fs = lal.CreateREAL8Vector(f_upper * int(1./metricParams.deltaF + 0.5) + 1)
    fs.data[:] = freqs[:]

    num_metric_params_TI.timephase_unprojected_metric[f_upper][-1,-1] = \
        num_metric_params_TI.timephase_unprojected_metric[f_upper][-1,-1] * num_metric_params_TI.f0 * num_metric_params_TI.f0
    for metric_idx in range(metric_size+1):
        num_metric_params_TI.timephase_unprojected_metric[f_upper][-1,metric_idx] = \
            num_metric_params_TI.timephase_unprojected_metric[f_upper][-1,metric_idx] * (num_metric_params_TI.f0)
        num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx,-1] = \
            num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx,-1] * (num_metric_params_TI.f0)

    # It seems I'm dividing everything by 0.5 ... Why?
    for metric_idx1 in range(metric_size+2):
        for metric_idx2 in range(metric_size+2):
            num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx1, metric_idx2] = \
                num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx1, metric_idx2] * 0.5

    for i in range(len(mass1s)):
            mass1 = mass1s[i]
            mass2 = mass2s[i]
            spin1z = spin1zs[i]
            spin2z = spin2zs[i]
            phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
                (mass1, mass2, spin1z, spin2z, laldict)
            wform1 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
                 lal.PC_SI*1000000, laldict, phasing)
            wform1 = FrequencySeries(wform1.data.data[:], delta_f=metricParams.deltaF,
                                     epoch=wform1.epoch)
            metric_size = len(num_metric_params_TI.evals[f_upper])

            # Time term
            diff = ((1 - desired_match) / num_metric_params_TI.timephase_unprojected_metric[f_upper][-1,-1])**0.5
            #print diff
            wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., diff,
                     lal.PC_SI*1000000, laldict, phasing)
            wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                         epoch=wform1.epoch)
            overlap = pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                   low_frequency_cutoff=15)
            overlap = overlap.real
            num_metric_params_TI.timephase_unprojected_metric[f_upper][-1,-1] \
                    = (1 - overlap) / (diff*diff)
            if (1 - overlap) / (diff*diff) < 0:
                print overlap, diff, 1- overlap
                raise ValueError()
            #print "-1, -1", overlap
            #print "T", "T", overlap#, mass1, mass2     
            #raise ValueError()
            
            # Phase term
            diff = ((1 - desired_match) / num_metric_params_TI.timephase_unprojected_metric[f_upper][-2,-2])**0.5
            #print diff
            new_phasing = lalsimulation.PNPhasingSeries()
            new_phasing.v[:] = phasing.v[:]
            new_phasing.vlogv[:] = phasing.vlogv[:]
            new_phasing.vlogvsq[:] = phasing.vlogvsq[:]
            new_phasing.v[5] = new_phasing.v[5] + diff

            wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0, mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0,
                     lal.PC_SI*1000000, laldict, new_phasing)
            wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                         epoch=wform1.epoch)
            overlap = pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                   low_frequency_cutoff=15)
            #print overlap, diff, 1- overlap
            overlap = overlap.real
            num_metric_params_TI.timephase_unprojected_metric[f_upper][-2,-2] \
                    = (1 - overlap) / (diff*diff)
            if (1 - overlap) / (diff*diff) < 0:
                print overlap, diff, 1- overlap
                raise ValueError()
            #print "-2, -2", overlap

            
            # Diagonal terms
            for metric_idx in range(metric_size):
                diff = ((1 - desired_match) / num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                        [metric_idx,metric_idx])**0.5
                new_phasing = pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                    (phasing, diff, metric_idx, mass1 + mass2,
                     num_metric_params_TI)
                wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
                     lal.PC_SI*1000000, laldict, new_phasing)
                wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                         epoch=wform1.epoch)
                overlap = (pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                    low_frequency_cutoff=15)).real
                num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx,metric_idx] \
                    = (1 - overlap) / (diff*diff)
                if (1 - overlap) / (diff*diff) < 0:
                    print overlap, diff, 1- overlap
                    raise ValueError()
                #print metric_idx, metric_idx, overlap
                #print metric_idx, metric_idx, overlap#, mass1, mass2
                #print num_metric_params.time_unprojected_metric[f_upper][metric_idx,metric_idx], num_metric_params.metric[f_upper][metric_idx,metric_idx]

            #print
            
            # Cross phase-time term
            curr_metric_1 = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                [-2, -2]
            curr_metric_2 = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                [-1, -1]
            curr_metric_C = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                [-2, -1]
            diff_ratio = (curr_metric_1 / curr_metric_2)**0.5
            diff1 = 1 - desired_match
            diff1 /= curr_metric_1 + 2*diff_ratio*curr_metric_C + \
                diff_ratio*diff_ratio*curr_metric_2
            if diff1 < 0:
                diff1 = 1 - desired_match
                diff1 /= curr_metric_1 + \
                    diff_ratio*diff_ratio*curr_metric_2
            diff1 = diff1**0.5
            diff2 = diff1 * diff_ratio
            if numpy.isnan(diff1) or numpy.isnan(curr_metric_1):
                    print "ERROR 111"
                    print curr_metric_1, curr_metric_2, curr_metric_C, diff1, diff2
                    print "ERROR 111"
                    raise ValueError()
            wform2 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, -diff1 / 2., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., diff2,
                 lal.PC_SI*1000000, laldict, phasing)
            wform2 = FrequencySeries\
                    (wform2.data.data[:], delta_f=metricParams.deltaF,
                     epoch=wform1.epoch)
            overlap = pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                   low_frequency_cutoff=15)
            #print "PHASE TIME OVERLAP", overlap, desired_match
            overlap = overlap.real
            new_metric_comp = - curr_metric_1 / diff_ratio - \
                    curr_metric_2 * diff_ratio + \
                    (1 - overlap) / (diff1 * diff2)
            new_metric_comp *= 0.5
            num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                    [-2,-1] = new_metric_comp
            num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                        [-1,-2] = new_metric_comp
            #print -2, -1, overlap

            
            # Cross time terms
            for metric_idx1 in range(metric_size):
                curr_metric_1 = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                    [metric_idx1, metric_idx1]
                curr_metric_2 = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                    [-1, -1]
                curr_metric_C = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                    [metric_idx1, -1]
                diff_ratio = (curr_metric_1 / curr_metric_2)**0.5
                diff1 = 1 - desired_match
                diff1 /= curr_metric_1 + 2*diff_ratio*curr_metric_C + \
                    diff_ratio*diff_ratio*curr_metric_2
                if diff1 < 0:
                    diff1 = 1 - desired_match
                    diff1 /= curr_metric_1 + \
                        diff_ratio*diff_ratio*curr_metric_2
                diff1 = diff1**0.5
                diff2 = diff1 * diff_ratio

                if numpy.isnan(diff1) or numpy.isnan(curr_metric_1):
                        print "ERROR"
                        print curr_metric_1, curr_metric_2, curr_metric_C, diff1, diff2
                        print "ERROR"
                        raise ValueError()
                new_phasing = \
                        pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                        (phasing, diff1, metric_idx1, mass1 + mass2,
                         num_metric_params_TI)
                wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., diff2,
                     lal.PC_SI*1000000, laldict, new_phasing)
                wform2 = FrequencySeries\
                        (wform2.data.data[:], delta_f=metricParams.deltaF,
                         epoch=wform1.epoch)
                overlap = (pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                       low_frequency_cutoff=15)).real
                new_metric_comp = - curr_metric_1 / diff_ratio - \
                        curr_metric_2 * diff_ratio + \
                        (1 - overlap) / (diff1 * diff2)
                new_metric_comp *= 0.5
                num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                        [metric_idx1,-1] = new_metric_comp
                num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                        [-1,metric_idx1] = new_metric_comp
                #print -1, metric_idx1, overlap
                #print metric_idx1, "T", overlap#, mass1, mass2
                #print curr_metric_1*diff1*diff1, curr_metric_2*diff2*diff2, curr_metric_C*diff1*diff2, curr_metric_1*diff1*diff1 + curr_metric_2*diff2*diff2 + 2*curr_metric_C*diff1*diff2
                #print

            # Cross phase terms
            for metric_idx1 in range(metric_size):
                curr_metric_1 = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                    [metric_idx1, metric_idx1]
                curr_metric_2 = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                    [-2, -2]
                curr_metric_C = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                    [metric_idx1, -2]
                if curr_metric_1 < 0 or curr_metric_2 < 0:
                    # This shouldn't happen. Hopefully next iteration it is fixed??
                    continue
                diff_ratio = (curr_metric_1 / curr_metric_2)**0.5
                diff1 = 1 - desired_match
                diff1 /= curr_metric_1 + 2*diff_ratio*curr_metric_C + \
                    diff_ratio*diff_ratio*curr_metric_2
                if diff1 < 0:
                    diff1 = 1 - desired_match
                    diff1 /= curr_metric_1 + \
                        diff_ratio*diff_ratio*curr_metric_2
                diff1 = diff1**0.5
                diff2 = diff1 * diff_ratio
                if numpy.isnan(diff1) or numpy.isnan(curr_metric_1):
                    print "ERROR 222"
                    print curr_metric_1, curr_metric_2, curr_metric_C, diff1, diff2
                    print "ERROR 222"
                    raise ValueError()
                new_phasing = \
                    pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                    (phasing, -diff1, metric_idx1, mass1 + mass2,
                     num_metric_params_TI)
                wform2 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, (diff2 / 2.), mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
                 lal.PC_SI*1000000, laldict, new_phasing)
                wform2 = FrequencySeries\
                    (wform2.data.data[:], delta_f=metricParams.deltaF,
                     epoch=wform1.epoch)
                overlap = (pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                   low_frequency_cutoff=15)).real
                new_metric_comp = - curr_metric_1 / diff_ratio - \
                    diff_ratio * curr_metric_2 + \
                    (1 - overlap) / (diff1 * diff2)
                new_metric_comp *= 0.5
                num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                    [metric_idx1,-2] = new_metric_comp
                num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                    [-2,metric_idx1] = new_metric_comp
                #print -2, metric_idx1, overlap



            # Cross terms
            for metric_idx1 in range(metric_size):
                for metric_idx2 in range(metric_size):
                    if metric_idx2 >= metric_idx1:
                        continue
                    curr_metric_1 = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                        [metric_idx1, metric_idx1]
                    curr_metric_2 = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                        [metric_idx2, metric_idx2]
                    curr_metric_C = num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                        [metric_idx1, metric_idx2]
                    if curr_metric_1 < 0 or curr_metric_2 < 0:
                        # This shouldn't happen. Hopefully next iteration it is fixed??
                        continue
                    diff_ratio = (curr_metric_1 / curr_metric_2)**0.5
                    diff1 = 1 - desired_match
                    diff1 /= curr_metric_1 + 2*diff_ratio*curr_metric_C + \
                        diff_ratio*diff_ratio*curr_metric_2
                    if diff1 < 0:
                        diff1 = 1 - desired_match
                        diff1 /= curr_metric_1 + \
                            diff_ratio*diff_ratio*curr_metric_2
                    diff1 = diff1**0.5
                    diff2 = diff1 * diff_ratio
                    if numpy.isnan(diff1) or numpy.isnan(curr_metric_1):
                        print "ERROR"
                        print curr_metric_1, curr_metric_2, curr_metric_C, diff1, diff2
                        print "ERROR"
                        raise ValueError()
                    new_phasing = \
                        pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                        (phasing, diff1, metric_idx1, mass1 + mass2,
                         num_metric_params_TI)
                    new_phasing = \
                        pycbc.tmpltbank.shift_lal_phasing_by_delta_lambda\
                        (new_phasing, diff2, metric_idx2, mass1 + mass2,
                         num_metric_params_TI, edit_in_place=True)
                    wform2 = lalsimulation.SimInspiralTaylorF2Core\
                    (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
                     lal.PC_SI*1000000, laldict, new_phasing)
                    wform2 = FrequencySeries\
                        (wform2.data.data[:], delta_f=metricParams.deltaF,
                         epoch=wform1.epoch)
                    overlap = (pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                                       low_frequency_cutoff=15)).real
                    new_metric_comp = - curr_metric_1 / diff_ratio - \
                        diff_ratio * curr_metric_2 + \
                        (1 - overlap) / (diff1 * diff2)
                    new_metric_comp *= 0.5
                    num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                        [metric_idx1,metric_idx2] = new_metric_comp
                    num_metric_params_TI.timephase_unprojected_metric[f_upper]\
                        [metric_idx2,metric_idx1] = new_metric_comp
                    #print metric_idx1, metric_idx2, overlap

                    #print metric_idx1, metric_idx2, overlap
                    #print curr_metric_1*diff1*diff1, curr_metric_2*diff2*diff2, curr_metric_C*diff1*diff2, curr_metric_1*diff1*diff1 + curr_metric_2*diff2*diff2 + 2*curr_metric_C*diff1*diff2
                    #print

    for metric_idx1 in range(metric_size):
        for metric_idx2 in range(metric_size):
            mc1 = num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx1, metric_idx2]
            mc2 = num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx1, -2] 
            mc3 = num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx2, -2]
            mc4 = num_metric_params_TI.timephase_unprojected_metric[f_upper][-2, -2]
            num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx1, metric_idx2] = mc1 - mc2*mc3 / mc4
        
        mc1 = num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx1, -1]
        mc2 = num_metric_params_TI.timephase_unprojected_metric[f_upper][metric_idx1, -2]
        mc3 = num_metric_params_TI.timephase_unprojected_metric[f_upper][-1, -2]
        mc4 = num_metric_params_TI.timephase_unprojected_metric[f_upper][-2, -2]
        num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx1, -1] = mc1 - mc2*mc3 / mc4
        num_metric_params_TI.time_unprojected_metric[f_upper][-1, metric_idx1] = mc1 - mc2*mc3 / mc4
        
    mc1 = num_metric_params_TI.timephase_unprojected_metric[f_upper][-1, -1]
    mc2 = num_metric_params_TI.timephase_unprojected_metric[f_upper][-1, -2]
    mc4 = num_metric_params_TI.timephase_unprojected_metric[f_upper][-2, -2]
    num_metric_params_TI.time_unprojected_metric[f_upper][-1, -1] = mc1 - mc2*mc2 / mc4
        
    for metric_idx1 in range(metric_size):
        for metric_idx2 in range(metric_size):
            mc1 = num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx1, metric_idx2]
            mc2 = num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx1, -1]
            mc3 = num_metric_params_TI.time_unprojected_metric[f_upper][metric_idx2, -1]
            mc4 = num_metric_params_TI.time_unprojected_metric[f_upper][-1, -1]
            num_metric_params_TI.metric[f_upper][metric_idx1, metric_idx2] = mc1 - mc2*mc3 / mc4
            
    return num_metric_params_TI

def shift_lal_phasing(lal_phasing, delta_lambda, lin_ord, log_ord, f0, total_mass):
    pim = lal.PI * (total_mass)*lal.MTSUN_SI
    pmf = pim * f0
    pmf13 = pmf**(1./3.)
    logpim13 = numpy.log((pim)**(1./3.))
    
    new_phasing = lalsimulation.PNPhasingSeries()
    new_phasing.v[:] = lal_phasing.v[:]
    new_phasing.vlogv[:] = lal_phasing.vlogv[:]
    new_phasing.vlogvsq[:] = lal_phasing.vlogvsq[:]
    
    if log_ord == 0:
        lal_diff = delta_lambda / (pmf13**(-5+lin_ord))
        new_phasing.v[lin_ord] = new_phasing.v[lin_ord] + lal_diff
    elif log_ord == 1:
        lal_l_diff = delta_lambda / (pmf13**(-5+lin_ord))
        new_phasing.vlogv[lin_ord] = new_phasing.vlogv[lin_ord] + lal_l_diff
        # Also need to change non log term
        pycbc_nl_diff = lal_l_diff * logpim13
        lal_nl_diff = - pycbc_nl_diff
        new_phasing.v[lin_ord] = new_phasing.v[lin_ord] + lal_nl_diff
    else:
        raise ValueError()
    return new_phasing


def compute_some_matches_pt_unmaximized(metricParams, desired_match):
    
    output_dict = {}
    
    num_metric_params_TI = copy.deepcopy(metricParams)

    metric_size = len(num_metric_params_TI.evals[f_upper])

    laldict = lal.CreateDict()
    # I need to create a waveform from a stock location. It shouldn't matter what this is, as we are going
    # to override the termination frequency anyway. The global parameter space stuff still seems to hold, so I
    # think only dlambda matters, not the original value of lambdas.
    mass1s, mass2s, spin1zs, spin2zs = \
         pycbc.tmpltbank.get_random_mass(1, massRangeParams)
    # And here's where we override what the frequencies will be. 
    freqs = numpy.arange(f_upper*int(1./metricParams.deltaF + 0.5)+1) * metricParams.deltaF
    fs = lal.CreateREAL8Vector(f_upper * int(1./metricParams.deltaF + 0.5) + 1)
    fs.data[:] = freqs[:]

    # Create our stock waveform. Note that we extract the phasing array so that we can directly change lambdas
    # and then generate a new waveform.
    mass1 = mass1s[0]
    mass2 = mass2s[0]
    spin1z = spin1zs[0]
    spin2z = spin2zs[0]
    phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
        (mass1, mass2, spin1z, spin2z, laldict)
    wform1 = lalsimulation.SimInspiralTaylorF2Core\
        (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
         lal.PC_SI*1000000, laldict, phasing)
    wform1 = FrequencySeries(wform1.data.data[:], delta_f=metricParams.deltaF,
                             epoch=wform1.epoch)
    
    def orders_generator():
        for log_term in [0,1]:
            for phase_order in range(13):
                # Unimplemented values
                if phase_order in set([8,9,11]):
                    continue
                if log_term == 1 and phase_order not in set([5,6]):
                    continue
                yield (phase_order, log_term)
    
    for lin_ord, log_ord in orders_generator():
        # Use Fisher Matrix to guess what we should move lambda by for a diff of [desired_match]
        fisher_matrix = num_metric_params_TI.moments[(7 - (lin_ord - 5)*2,log_ord*2)][f_upper] * 0.5
        overlap = 0
        # We're then going to iterate to figure out what we need to do to get desired_match
        int_count = 0
        while abs((overlap - desired_match) / (1-desired_match)) > 0.00001:       
            diff = ((1 - desired_match) / fisher_matrix)**0.5
            # Explicitly shift the phasing array by this amount        
            new_phasing = shift_lal_phasing(phasing, diff, lin_ord, log_ord, num_metric_params_TI.f0, mass1 + mass2)
            wform2 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
                 lal.PC_SI*1000000, laldict, new_phasing)
            wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                     epoch=wform1.epoch)
            overlap = (pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                       low_frequency_cutoff=15)).real
            #print overlap, desired_match, diff, lin_ord, log_ord
            fisher_matrix = (1 - overlap) / diff**2
            int_count += 1
            if int_count > 30:
                print overlap, desired_match, diff, lin_ord, log_ord
                raise ValueError()
        diff = ((1 - desired_match) / fisher_matrix)**0.5

        curr_out = [1]
        for i in range(1, 21):
            curr_contribution = num_metric_params_TI.moments[(7 - (lin_ord - 5)*(2*i),log_ord*(2*i))][f_upper] * diff**(2*i)
            curr_out.append(curr_contribution / math.factorial(2*i) * (-1)**i)
        
        output_dict[(lin_ord, log_ord)] = [tuple(curr_out), diff]

    return output_dict


class MetrixTensor(object):
    
    def __init__(self, moments, f_upper):
        self.moments = moments
        self.f_upper = f_upper
    
    def return_val_from_lambda_tuples(self, order, lambda_tuples):
        assert len(lambda_tuples) == order
        
        linear_term = 7
        log_term = 0
        for lin, log in lambda_tuples:
            linear_term = linear_term - (lin - 5)
            log_term = log_term + log
        curr_mom = self.moments[(linear_term, log_term)][self.f_upper]
        return curr_mom / math.factorial(order) * (-1)**(order//2)


# First I need some outside help. I need to know the number of unique permutations of a "multiset". So when
# considering the 8th order metric correction (for e.g.) I might have dx1 * dx1 * dx1 * dx2 * dx2 * dx3 * dx3 * dx4
# Rather than looping over dx in 8 loops I can just identify how many permutations of this would occur and use that.
#
# Still computing generic matches at 8th order (and above) is going to be slow, but it's a start.

# https://stackoverflow.com/questions/6284396/permutations-with-unique-values offers some solutions. I'll print both here

# !~/miniconda3/envs/py27/bin/pip install sympy

# from sympy.utilities.iterables import multiset_permutations

class unique_element:
    def __init__(self,value,occurrences):
        self.value = value
        self.occurrences = occurrences

_perm_unique_called_cache = {}
def perm_unique_called(input_tuple):
    # Sanitize input
    input_tuple = tuple(sorted(input_tuple))
    if input_tuple in _perm_unique_called_cache:
        return _perm_unique_called_cache[input_tuple]
    input_list = []
    counter = 0
    for val in input_tuple:
        input_list += [counter] * val
        counter += 1
    
    ret_val = perm_unique(input_list)
    _perm_unique_called_cache[input_tuple] = ret_val
    return ret_val

def perm_unique(elements):
    eset=set(elements)
    listunique = [unique_element(i,elements.count(i)) for i in eset]
    u=len(elements)
    count = [0]
    perm_unique_helper(listunique,[0]*u,u-1,count)
    return count[0]

def perm_unique_helper(listunique,result_list,d,count):
    if d < 0:
        count[0] += 1
    else:
        for i in listunique:
            if i.occurrences > 0:
                result_list[d]=i.value
                i.occurrences-=1
                perm_unique_helper(listunique,result_list,d-1,count)
                i.occurrences+=1


def create_2d_variations(met_tensor, lambda1_tuple, lambda2_tuple, desired_match, relative_scale=1.0, nvals=100):
    
    output_dict = {}

    metric_size = len(metricParams.evals[f_upper])

    laldict = lal.CreateDict()
    # I need to create a waveform from a stock location. It shouldn't matter what this is, as we are going
    # to override the termination frequency anyway. The global parameter space stuff still seems to hold, so I
    # think only dlambda matters, not the original value of lambdas.
    mass1s, mass2s, spin1zs, spin2zs = \
         pycbc.tmpltbank.get_random_mass(1, massRangeParams)
    # And here's where we override what the frequencies will be. 
    freqs = numpy.arange(f_upper*int(1./metricParams.deltaF + 0.5)+1) * metricParams.deltaF
    fs = lal.CreateREAL8Vector(f_upper * int(1./metricParams.deltaF + 0.5) + 1)
    fs.data[:] = freqs[:]

    # Create our stock waveform. Note that we extract the phasing array so that we can directly change lambdas
    # and then generate a new waveform.
    mass1 = mass1s[0]
    mass2 = mass2s[0]
    spin1z = spin1zs[0]
    spin2z = spin2zs[0]
    phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
        (mass1, mass2, spin1z, spin2z, laldict)
    wform1 = lalsimulation.SimInspiralTaylorF2Core\
        (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
         lal.PC_SI*1000000, laldict, phasing)
    wform1 = FrequencySeries(wform1.data.data[:], delta_f=metricParams.deltaF,
                             epoch=wform1.epoch)

    for angle in numpy.linspace(0, 2*numpy.pi, nvals):
        #print "ANGLE", angle
        # Use Fisher Matrix to guess what we should move lambda by for a diff of [desired_match]
        fisher_matrix_aa = - met_tensor.return_val_from_lambda_tuples(2, [lambda1_tuple, lambda1_tuple])
        fisher_matrix_bb = - met_tensor.return_val_from_lambda_tuples(2, [lambda2_tuple, lambda2_tuple])
        fisher_matrix_ab = - met_tensor.return_val_from_lambda_tuples(2, [lambda1_tuple, lambda2_tuple])

        overlap = 0
        # We're then going to iterate to figure out what we need to do to get desired_match
        int_count = 0
        
        diff_ratio = numpy.tan(angle) * relative_scale
        diff1 = 1 - desired_match
        diff1 /= fisher_matrix_aa + 2*diff_ratio*fisher_matrix_ab + \
            diff_ratio*diff_ratio*fisher_matrix_bb
        if diff1 < 0:
            print diff1, fisher_matrix_aa, diff_ratio*diff_ratio*fisher_matrix_bb, 2*diff_ratio*fisher_matrix_ab
            raise ValueError()
        diff1 = diff1**0.5
        if angle > (numpy.pi/2) and angle < (3*numpy.pi/2.):
            diff1 = -diff1
        diff2 = diff1 * diff_ratio
        scale_factor = 1

        while abs((overlap - desired_match) / (1-desired_match)) > 0.00001:
            #print "IN LOOP"
            # Explicitly shift the phasing array by this amount        
            new_phasing = shift_lal_phasing(phasing, diff1*scale_factor, lambda1_tuple[0], lambda1_tuple[1],
                                            metricParams.f0, mass1 + mass2)
            new_phasing = shift_lal_phasing(new_phasing, diff2*scale_factor, lambda2_tuple[0], lambda2_tuple[1],
                                            metricParams.f0, mass1 + mass2)

            wform2 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
                 lal.PC_SI*1000000, laldict, new_phasing)
            wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                     epoch=wform1.epoch)
            overlap = (pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                       low_frequency_cutoff=15)).real
            #print overlap, desired_match, diff, lin_ord, log_ord
            error = (1 - desired_match) / (1 - overlap)
            scale_factor = scale_factor * error**0.5
            int_count += 1
            if int_count > 60:
                print overlap, desired_match, diff, lin_ord, log_ord
                raise ValueError()
        diff1 = diff1 * scale_factor
        diff2 = diff2 * scale_factor

        # What match do we get with the metric to different orders and the current diffs
        current_matches = [1]
        curr_match = 1
        for i in range(1, 11):
            curr_contribution = 0
            for j in range(i*2 + 1):
                tuple_list = [lambda1_tuple]*j + [lambda2_tuple]*(i*2 - j)
                curr_tensor = met_tensor.return_val_from_lambda_tuples(i*2, tuple_list) * diff1**j * diff2**(i*2-j)
                #print "HI", j,i*2 - j
                curr_number = perm_unique_called([j,i*2 - j])
                curr_contribution += curr_tensor * curr_number
                #print curr_tensor * curr_number

            curr_match += curr_contribution
            #print curr_match, "DEBUGGING"
            current_matches.append(curr_match)

        # Can we change the diffs to get the metric to predict desired_match??
        rescaled_diffs = []
          
        for JK in [1]:
            curr_mismatch_frac = 1
            scale_factor = 1
            int_count = 0
            while abs(curr_mismatch_frac) > 0.00001:
                curr_match = 1
                d1 = diff1 * scale_factor
                d2 = diff2 * scale_factor
                for i in range(1, JK+1):
                    curr_contribution = 0
                    for j in range(i*2 + 1):
                        tuple_list = [lambda1_tuple]*j + [lambda2_tuple]*(i*2 - j)
                        curr_tensor = met_tensor.return_val_from_lambda_tuples(i*2, tuple_list) * d1**j * d2**(i*2-j)
                        #print "HI", j,i*2 - j
                        curr_number = perm_unique_called([j,i*2 - j])
                        curr_contribution += curr_tensor * curr_number
                        print "DB", i, j, met_tensor.return_val_from_lambda_tuples(i*2, tuple_list), d1**j, d2**(i*2-j)
                        #print curr_tensor * curr_number

                    curr_match += curr_contribution
                curr_mismatch_frac = (desired_match - curr_match) / (1-desired_match)
                error = (1 - desired_match) / (1 - curr_match)
                scale_factor = scale_factor * error**0.5
                #print curr_match, "DEBUGGING"
                int_count += 1
                if int_count > 60:
                    raise ValueError()
            rescaled_diffs.append((diff1 * scale_factor, diff2 * scale_factor))

        
        output_dict[angle] = [current_matches, rescaled_diffs, diff1, diff2]
    
    return output_dict


def SimInspiralTaylorF2Phasing_10PNTidalCoeff(mByM):
    return (-288. + 264.*mByM)*mByM*mByM*mByM*mByM

def SimInspiralTaylorF2Phasing_12PNTidalCoeff(mByM):
    return (-15895./28. + 4595./28.*mByM + 5715./14.*mByM*mByM - 325./7.*mByM*mByM*mByM)*mByM*mByM*mByM*mByM


def lambda1_lambda2_masses_to_10_12_pn_lambdas(lambda1, lambda2, mass1, mass2, f0):
    m1m = mass1 / (mass1 + mass2)
    m2m = mass2 / (mass1 + mass2)
    totmass = mass1 + mass2
    eta = mass1*mass2 / (totmass*totmass)
    pfaN = 3. / (128. * eta)
    v10 = lambda1 * SimInspiralTaylorF2Phasing_10PNTidalCoeff(m1m)
    v10 += lambda2 * SimInspiralTaylorF2Phasing_10PNTidalCoeff(m2m)
    v12 = lambda1 * SimInspiralTaylorF2Phasing_12PNTidalCoeff(m1m)
    v12 += lambda2 * SimInspiralTaylorF2Phasing_12PNTidalCoeff(m2m)
    pim = lal.PI * (mass1+mass2)*lal.MTSUN_SI
    pmf = pim * f0
    pmf13 = pmf**(1./3.)
    
    lambda10 = v10 * (pmf13**(-5+10)) * pfaN
    lambda12 = v12 * (pmf13**(-5+12)) * pfaN
    
    return lambda10, lambda12

def delta_lambda(mass1, mass2, lambda1, lambda2):
    totmass = mass1 + mass2
    eta = mass1*mass2 / (totmass*totmass)
    term1 = (1 - 4*eta)**0.5 * (1 - eta * 13272./1319. + eta*eta*8944./1319)
    term1 = term1 * (lambda1 + lambda2)
    term2 = (1 - 15910./1319. * eta + 32850./1319. * eta * eta + 3380./1319. * eta*eta*eta)
    term2 = term2 * (lambda1 - lambda2)
    #print (lambda1, lambda2, term1, term2)
    return 0.5 * (term1 + term2)


def create_2d_variations_physical(met_tensor, desired_match, relative_scale=1.0):
    
    output_dict = {}

    metric_size = len(metricParams.evals[f_upper])

    laldict = lal.CreateDict()
    lalsimulation.SimInspiralWaveformParamsInsertPNTidalOrder(laldict, 12)
    # I need to create a waveform from a stock location. It shouldn't matter what this is, as we are going
    # to override the termination frequency anyway. The global parameter space stuff still seems to hold, so I
    # think only dlambda matters, not the original value of lambdas.
    mass1s, mass2s, spin1zs, spin2zs = \
         pycbc.tmpltbank.get_random_mass(1, massRangeParams)
    # And here's where we override what the frequencies will be. 
    freqs = numpy.arange(f_upper*int(1./metricParams.deltaF + 0.5)+1) * metricParams.deltaF
    fs = lal.CreateREAL8Vector(f_upper * int(1./metricParams.deltaF + 0.5) + 1)
    fs.data[:] = freqs[:]

    # Create our stock waveform. Note that we extract the phasing array so that we can directly change lambdas
    # and then generate a new waveform.
    mass1 = 1.5
    mass2 = 1.0
    spin1z = 0.
    spin2z = 0.
    lambda1 = 0
    lambda2 = 0
    lalsimulation.SimInspiralWaveformParamsInsertdQuadMon1(laldict, 0.)
    lalsimulation.SimInspiralWaveformParamsInsertdQuadMon2(laldict, 0.)
    lalsimulation.SimInspiralWaveformParamsInsertTidalLambda1(laldict, lambda1)
    lalsimulation.SimInspiralWaveformParamsInsertTidalLambda2(laldict, lambda2)

    phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
        (mass1, mass2, spin1z, spin2z, laldict)
    wform1 = lalsimulation.SimInspiralTaylorF2Core\
        (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
         lal.PC_SI*1000000, laldict, phasing)
    wform1 = FrequencySeries(wform1.data.data[:], delta_f=metricParams.deltaF,
                             epoch=wform1.epoch)
    
    #angles = list(numpy.linspace(0, 2*numpy.pi, 200))
    #angles = angles + list(numpy.linspace(1.775, 1.875, 200))
    #angles = angles + list(numpy.linspace(1.837, 1.839, 200))

    #angles = angles + list(numpy.linspace(4.90, 5.05, 200))
    #angles = angles + list(numpy.linspace(4.9785, 4.9805, 200))

    angles = list(numpy.linspace(0, 2*numpy.pi, 100))
    angles = angles + list(numpy.linspace(1.775, 1.875, 100))
    angles = angles + list(numpy.linspace(1.836, 1.843, 100))
    angles = angles + list(numpy.linspace(1.8385, 1.83895, 100))


    angles = angles + list(numpy.linspace(4.90, 5.05, 100))
    angles = angles + list(numpy.linspace(4.975, 4.986, 100))
    angles = angles + list(numpy.linspace(4.9795, 4.9805, 100))


    #angles = angles + list(numpy.linspace(2.354, 2.358, 200))
    #angles = angles + list(numpy.linspace(5.496, 5.500, 200))


    for angle in angles:
        overlap = 0
        # We're then going to iterate to figure out what we need to do to get desired_match
        int_count = 0
        
        diff_ratio = numpy.tan(angle) * relative_scale
        diff1 = 10
        
        if angle < numpy.pi / 2. or angle > 3.* numpy.pi / 2.:
            diff1 = -10
        diff2 = diff1 * diff_ratio
        scale_factor = 1

        while abs((overlap - desired_match) / (1-desired_match)) > 0.00001:
            #print "IN LOOP"
            # Explicitly shift the phasing array by this amount 
            l1 = lambda1 + diff1 * scale_factor
            l2 = lambda2 + diff2 * scale_factor
            lalsimulation.SimInspiralWaveformParamsInsertTidalLambda1(laldict, l1)
            lalsimulation.SimInspiralWaveformParamsInsertTidalLambda2(laldict, l2)
            phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
                (mass1, mass2, spin1z, spin2z, laldict)
            wform2 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
                 lal.PC_SI*1000000, laldict, phasing)
            wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                     epoch=wform1.epoch)
            overlap = (pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                       low_frequency_cutoff=15)).real
            #print overlap, desired_match, diff, lin_ord, log_ord
            error = (1 - desired_match) / (1 - overlap)
            scale_factor = scale_factor * error**0.5
            int_count += 1
            if int_count > 60:
                print overlap, desired_match, diff, lin_ord, log_ord
                raise ValueError()
        diff1 = diff1 * scale_factor
        diff2 = diff2 * scale_factor
        
        ldiff1, ldiff2 = lambda1_lambda2_masses_to_10_12_pn_lambdas(diff1, diff2, mass1, mass2, metricParams.f0)
        
        # What match do we get with the metric to different orders and the current diffs
        # FIXME: HARDCODED FOR TIDAL TERM CHANGES ONLY!!
        current_matches = [1]
        curr_match = 1
        for i in range(1, 11):
            curr_contribution = 0
            for j in range(i*2 + 1):
                tuple_list = [(10,0)]*j + [(12,0)]*(i*2 - j)
                curr_tensor = met_tensor.return_val_from_lambda_tuples(i*2, tuple_list) * ldiff1**j * ldiff2**(i*2-j)
                #print "HI", j,i*2 - j
                curr_number = perm_unique_called([j,i*2 - j])
                curr_contribution += curr_tensor * curr_number
                #print curr_tensor * curr_number

            curr_match += curr_contribution
            #print curr_match, "DEBUGGING"
            current_matches.append(curr_match)

        # Can we change the diffs to get the metric to predict desired_match??
        rescaled_diffs = []
          
        for JK in range(1, 2):
            curr_mismatch_frac = 1
            scale_factor = 1
            int_count = 0
            while abs(curr_mismatch_frac) > 0.00001:
                curr_match = 1
                d1 = ldiff1 * scale_factor
                d2 = ldiff2 * scale_factor
                for i in range(1, JK+1):
                    curr_contribution = 0
                    for j in range(i*2 + 1):
                        tuple_list = [(10,0)]*j + [(12,0)]*(i*2 - j)
                        curr_tensor = met_tensor.return_val_from_lambda_tuples(i*2, tuple_list) * d1**j * d2**(i*2-j)
                        #print "HI", j,i*2 - j
                        curr_number = perm_unique_called([j,i*2 - j])
                        curr_contribution += curr_tensor * curr_number
                        #print curr_tensor * curr_number

                    curr_match += curr_contribution
                curr_mismatch_frac = (desired_match - curr_match) / (1-desired_match)
                error = (1 - desired_match) / (1 - curr_match)
                scale_factor = scale_factor * error**0.5
                #print curr_match, "DEBUGGING"
                int_count += 1
                if int_count > 30:
                    raise ValueError()
            leff = pycbc.conversions.lambda_tilde(mass1, mass2, diff1 * scale_factor, diff2 * scale_factor)
            dlambda = delta_lambda(mass1, mass2, diff1 * scale_factor, diff2 * scale_factor)
            rescaled_diffs.append((leff, dlambda, diff1 * scale_factor, diff2 * scale_factor))

        leff = pycbc.conversions.lambda_tilde(mass1, mass2, diff1, diff2)
        dlambda = delta_lambda(mass1, mass2, diff1, diff2)
        output_dict[angle] = [current_matches, rescaled_diffs, diff1, diff2, leff, dlambda]
    
    return output_dict


def phasing_to_lambdas_35pn(phasing_arr, f0, mass1, mass2):
    m1m = mass1 / (mass1 + mass2)
    m2m = mass2 / (mass1 + mass2)
    totmass = mass1 + mass2
    eta = mass1*mass2 / (totmass*totmass)
    pfaN = 3. / (128. * eta)
    pim = lal.PI * (mass1+mass2)*lal.MTSUN_SI
    pmf = pim * f0
    pmf13 = pmf**(1./3.)
    logpim13 = numpy.log((pim)**(1./3.))
    
    lambdas = {}
    
    for i in [0,2,3,4,5,6,7]:
        term = phasing_arr.v[i]
        term = term + logpim13 * phasing_arr.vlogv[i]
        lambdas[(i,0)] = term * pmf13**(-5 + i)
    for i in [5,6]:
        lambdas[(i,1)] = phasing_arr.vlogv[i] * pmf13**(-5 + i)
    return lambdas


def create_2d_variations_physical_mass(met_tensor, desired_match, relative_scale=1.0):
    
    output_dict = {}

    metric_size = len(metricParams.evals[f_upper])

    laldict = lal.CreateDict()
    lalsimulation.SimInspiralWaveformParamsInsertPNTidalOrder(laldict, 12)
    # And here's where we override what the frequencies will be. 
    freqs = numpy.arange(f_upper*int(1./metricParams.deltaF + 0.5)+1) * metricParams.deltaF
    fs = lal.CreateREAL8Vector(f_upper * int(1./metricParams.deltaF + 0.5) + 1)
    fs.data[:] = freqs[:]

    # Create our stock waveform. Note that we extract the phasing array so that we can directly change lambdas
    # and then generate a new waveform.
    mass1 = 1.5
    mass2 = 1.0
    mchirp = pycbc.conversions.mchirp_from_mass1_mass2(mass1, mass2)
    eta = pycbc.conversions.eta_from_mass1_mass2(mass1, mass2)
    print mchirp, eta
    spin1z = 0.
    spin2z = 0.
    lambda1 = 0
    lambda2 = 0
    lalsimulation.SimInspiralWaveformParamsInsertdQuadMon1(laldict, 0.)
    lalsimulation.SimInspiralWaveformParamsInsertdQuadMon2(laldict, 0.)
    lalsimulation.SimInspiralWaveformParamsInsertTidalLambda1(laldict, lambda1)
    lalsimulation.SimInspiralWaveformParamsInsertTidalLambda2(laldict, lambda2)

    phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
        (mass1, mass2, spin1z, spin2z, laldict)
    wform1 = lalsimulation.SimInspiralTaylorF2Core\
        (fs, 0., mass1*lal.MSUN_SI, mass2*lal.MSUN_SI, 0., 0.,
         lal.PC_SI*1000000, laldict, phasing)
    wform1 = FrequencySeries(wform1.data.data[:], delta_f=metricParams.deltaF,
                             epoch=wform1.epoch)
    lambdas0 = phasing_to_lambdas_35pn(phasing, metricParams.f0, mass1, mass2)

    
    angles = list(numpy.linspace(0, 2*numpy.pi, 100))
    angles = angles + list(numpy.linspace(1.4, 1.6, 100))
    angles = angles + list(numpy.linspace(4.53, 4.73, 100))

    #angles = angles + list(numpy.linspace(1.836, 1.843, 100))
    #angles = angles + list(numpy.linspace(1.8385, 1.83895, 100))

    for angle in angles:
        overlap = 0
        # We're then going to iterate to figure out what we need to do to get desired_match
        int_count = 0
        
        diff_ratio = numpy.tan(angle) * relative_scale
        diff1 = 0.0001
        
        if angle < numpy.pi / 2. or angle > 3.* numpy.pi / 2.:
            diff1 = -0.01
        diff2 = diff1 * diff_ratio
        diff_abs = (diff1**2 + diff2**2)**0.5
        diff1 = diff1 * 0.000001 / diff_abs
        diff2 = diff2 * 0.000001 / diff_abs
        
        scale_factor = 1
        #print mchirp, eta
        while abs((overlap - desired_match) / (1-desired_match)) > 0.00001:
            #print "IN LOOP"
            # Explicitly shift the phasing array by this amount 
            mc = mchirp + diff1 * scale_factor
            et = eta + diff2 * scale_factor
            m1 = pycbc.conversions.mass1_from_mchirp_eta(mc, et)
            m2 = pycbc.conversions.mass2_from_mchirp_eta(mc, et)
            phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
                (m1, m2, spin1z, spin2z, laldict)
            wform2 = lalsimulation.SimInspiralTaylorF2Core\
                (fs, 0., m1*lal.MSUN_SI, m2*lal.MSUN_SI, 0., 0.,
                 lal.PC_SI*1000000, laldict, phasing)
            wform2 = FrequencySeries(wform2.data.data[:], delta_f=metricParams.deltaF,
                                     epoch=wform1.epoch)
            overlap = (pycbc.filter.overlap_cplx(wform1, wform2, psd=psd,
                       low_frequency_cutoff=15)).real
            #print "D", overlap, mc, et, m1, m2
            #print overlap, scale_factor
            #print overlap, desired_match, diff, lin_ord, log_ord
            error = (1 - desired_match) / (1 - overlap)
            scale_factor = scale_factor * error**0.5
            int_count += 1
            if int_count > 60:
                print overlap, desired_match, diff, lin_ord, log_ord
                raise ValueError()
        diff1 = diff1 * scale_factor
        diff2 = diff2 * scale_factor
        mc = mchirp + diff1
        et = eta + diff2
        m1 = pycbc.conversions.mass1_from_mchirp_eta(mc, et)
        m2 = pycbc.conversions.mass2_from_mchirp_eta(mc, et)
        phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
            (m1, m2, spin1z, spin2z, laldict)
        m1_s = m1
        m2_s = m2

        #print "DONE"
        #print "D", m1, m2, mass1 + diff1, mass2 + diff2
        lambdas1 = phasing_to_lambdas_35pn(phasing, metricParams.f0, m1, m2)
        
        # What match do we get with the metric to different orders and the current diffs
        # FIXME: HARDCODED FOR TIDAL TERM CHANGES ONLY!!
        current_matches = [1]
        curr_match = 1
        #for i in []:
        #    curr_contribution = 0
        #    for j in range(i*2 + 1):
        #        tuple_list = [(10,0)]*j + [(12,0)]*(i*2 - j)
        #        curr_tensor = met_tensor.return_val_from_lambda_tuples(i*2, tuple_list) * ldiff1**j * ldiff2**(i*2-j)
                #print "HI", j,i*2 - j
        #        curr_number = perm_unique_called([j,i*2 - j])
        #        curr_contribution += curr_tensor * curr_number
                #print curr_tensor * curr_number

        #    curr_match += curr_contribution
            #print curr_match, "DEBUGGING"
        #    current_matches.append(curr_match)

        # Can we change the diffs to get the metric to predict desired_match??
        rescaled_diffs = []
        
        curr_mismatch_frac = 1
        scale_factor = 1
        int_count = 0
        while abs(curr_mismatch_frac) > 0.001:
            curr_match = 1
            #print "DB", met_tensor.return_val_from_lambda_tuples(2, [(0,0),(0,0)]), lambdas0[(0,0)] - lambdas1[(0,0)]
            for l1 in [(0,0), (2,0), (3,0), (4,0), (5,0), (6,0), (7,0), (5,1), (6,1)]:
                for l2 in [(0,0), (2,0), (3,0), (4,0), (5,0), (6,0), (7,0), (5,1), (6,1)]:
                    d1 = lambdas0[l1] - lambdas1[l1]
                    d2 = lambdas0[l2] - lambdas1[l2]
                    curr_tensor = met_tensor.return_val_from_lambda_tuples(2, [l1,l2])  * d1 * d2
                    curr_match += curr_tensor
                    #print d1, d2, curr_tensor
            #raise ValueError()
            curr_mismatch_frac = (desired_match - curr_match) / (1-desired_match)
            error = (1 - desired_match) / (1 - curr_match)
            scale_factor = scale_factor * error**0.5
            int_count += 1
            if int_count > 100:
                print curr_match, scale_factor, diff1, diff2
                raise ValueError()
            mc = mchirp + diff1 * scale_factor
            et = eta + diff2 * scale_factor
            m1 = pycbc.conversions.mass1_from_mchirp_eta(mc, et)
            m2 = pycbc.conversions.mass2_from_mchirp_eta(mc, et)
            phasing = lalsimulation.SimInspiralTaylorF2AlignedPhasing\
                (m1, m2, spin1z, spin2z, laldict)

            lambdas1 = phasing_to_lambdas_35pn(phasing, metricParams.f0, m1, m2)

        if int_count > 100:
            continue
        
        #print "DONE"
          
        #for JK in range(1, 2):
        #    curr_mismatch_frac = 1
        #    scale_factor = 1
        #    int_count = 0
        #    while abs(curr_mismatch_frac) > 0.00001:
        #        curr_match = 1
        #        d1 = ldiff1 * scale_factor
        #        d2 = ldiff2 * scale_factor
        #        for i in range(1, JK+1):
        #            curr_contribution = 0
        #            for j in range(i*2 + 1):
        #                tuple_list = [(10,0)]*j + [(12,0)]*(i*2 - j)
        #                curr_tensor = met_tensor.return_val_from_lambda_tuples(i*2, tuple_list) * d1**j * d2**(i*2-j)
                        #print "HI", j,i*2 - j
        #                curr_number = perm_unique_called([j,i*2 - j])
        #                curr_contribution += curr_tensor * curr_number
                        #print curr_tensor * curr_number

        #            curr_match += curr_contribution
        #        curr_mismatch_frac = (desired_match - curr_match) / (1-desired_match)
        #        error = (1 - desired_match) / (1 - curr_match)
        #        scale_factor = scale_factor * error**0.5
                #print curr_match, "DEBUGGING"
        #        int_count += 1
        #        if int_count > 30:
        #            raise ValueError()
        rescaled_diffs.append((mchirp + diff1 * scale_factor, eta + diff2 * scale_factor))
        output_dict[angle] = [current_matches, rescaled_diffs, mchirp + diff1, eta + diff2]
    
    return output_dict

