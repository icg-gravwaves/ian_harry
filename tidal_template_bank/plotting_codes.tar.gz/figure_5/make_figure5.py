import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.style.use(['seaborn-talk','paper'])

from support import *

o2des = {}
o2des[0.97] = {}

for f_upper in [512, 1024, 2048]:
    metricParams = gen_metric_params(f_upper)
 
    met_tensor = MetrixTensor(metricParams.moments, f_upper)

    desired_match = 0.97
    output_2d_example_097 = create_2d_variations(met_tensor, [10,0], [12,0], desired_match, metricParams, f_upper, relative_scale=0.2, nvals=500)

    o2des[desired_match][f_upper] = output_2d_example_097


# Make plot of output_2d_example

pylab.figure()

colorloop = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']

for overlap in [0.97]:
  o2de_dict = o2des[overlap]
  count = 0
  for f_upper in [2048, 1024, 512]:
    o2de = o2de_dict[f_upper]
    proper_points_x = []
    proper_points_y = []
    calculated_points_x = {}
    calculated_points_y = {}
    matches = {}
    for i in range(1, 11):
        calculated_points_x[i] = []
        calculated_points_y[i] = []
        matches[i] = []

    sorted_keys = sorted(o2de.keys())
    for key in sorted_keys:
        diff1 = o2de[key][2]
        diff2 = o2de[key][3]
        proper_points_x.append(diff1)
        proper_points_y.append(diff2)
        curr_diff = 1
        for i in [1]:
            curr_diff = o2de[key][1][i-1]
            calculated_points_x[i].append(curr_diff[0])
            calculated_points_y[i].append(curr_diff[1])

    pylab.plot((numpy.array(calculated_points_x[1])), (numpy.array(calculated_points_y[1])), color=colorloop[count], linestyle='--')
    count += 1

pylab.legend(['2048Hz', '1024Hz', '512Hz'])

for overlap in [0.97]:
  o2de_dict = o2des[overlap]
  count = 0
  for f_upper in [2048, 1024, 512]:
    o2de = o2de_dict[f_upper]
    proper_points_x = []
    proper_points_y = []
    calculated_points_x = {}
    calculated_points_y = {}
    matches = {}
    for i in range(1, 11):
        calculated_points_x[i] = []
        calculated_points_y[i] = []
        matches[i] = []

    sorted_keys = sorted(o2de.keys())
    for key in sorted_keys:
        diff1 = o2de[key][2]
        diff2 = o2de[key][3]
        proper_points_x.append(diff1)
        proper_points_y.append(diff2)
        curr_diff = 1
        for i in [1]:
            curr_diff = o2de[key][1][i-1]
            calculated_points_x[i].append(curr_diff[0])
            calculated_points_y[i].append(curr_diff[1])

    pylab.plot((numpy.array(proper_points_x)), 
               (numpy.array(proper_points_y)), color=colorloop[count],
               linestyle='-')
    count += 1

pylab.xlabel('$\Delta \lambda_{10,0}$')
pylab.ylabel('$\Delta \lambda_{12,0}$')
pylab.savefig('Figure5.pdf')
