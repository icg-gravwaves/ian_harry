/home/spxiwh/src/ffmpeg-git-20201104-amd64-static/ffmpeg -r 1 -f image2 -i Figure5_video_panel_%d.png -vcodec libx264 -crf 25  -pix_fmt yuv420p -vf pad="width=ceil(iw/2)*2:height=ceil(ih/2)*2" -start_number 0 test.mp4

